import { Component } from '@angular/core';

@Component({
  selector: 'app-window',
  templateUrl: './window.component.html'
})
export class WindowComponent {
  heading = 'Pharmacy Demo Window';
}